package vcmsa.ci.myapplication;

import android.app.Activity;

public class DetailedActivity extends Activity {
}
