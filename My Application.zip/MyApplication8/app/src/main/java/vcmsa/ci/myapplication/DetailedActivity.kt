package com.example.myapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import vcmsa.ci.myapplication.R

class DetailedViewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailed)

        // Get temperature data from intent
        val temps = intent.getDoubleArrayExtra("temps") ?: DoubleArray(7)

        // Initialize TextViews for each day
        val dayTextViews = List(7) { i ->
            findViewById<TextView>(
                resources.getIdentifier("tvDay${i + 1}", "id", packageName)
            )
        }

        // Display daily temperatures
        dayTextViews.forEachIndexed { i, tv ->
            tv.text = "Day ${i + 1}: %.2f°C".format(temps[i])
        }

        // Display max and min
        findViewById<TextView>(R.id.tvMax).text = "Max: %.2f°C".format(temps.maxOrNull() ?: 0.0)
        findViewById<TextView>(R.id.tvMin).text = "Min: %.2f°C".format(temps.minOrNull() ?: 0.0)

        // Back button to finish activity
        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish()
        }
    }
}


