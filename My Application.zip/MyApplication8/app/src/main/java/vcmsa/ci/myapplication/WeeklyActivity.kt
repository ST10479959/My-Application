package com.example.myapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Parcel
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import vcmsa.ci.myapplication.R

class WeeklyActivity : AppCompatActivity() {
    private val temps = DoubleArray(7)
    private lateinit var inputs: List<EditText>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)
        setContentView(R.layout.activity_splash)

        inputs = List(7) { i ->
            findViewById(resources.getIdentifier("etDay${i+1}", "id", packageName))
        }

        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val btnDetails = findViewById<Button>(R.id.btnDetails)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val btnExit = findViewById<Button>(R.id.btnExit)
        val tvAvg = findViewById<TextView>(R.id.tvAvg)

        btnCalculate.setOnClickListener {
            var valid = true
            for (i in temps.indices) {
                val inputValue = inputs[i].text.toString().toDoubleOrNull()
                if (inputValue == null) {
                    inputs[i].error = "Number required"
                    valid = false
                } else {
                    temps[i] = inputValue
                }
            }
            if (valid) {
                val average = temps.average()  // DoubleArray.average() :contentReference[oaicite:2]{index=2}
                tvAvg.text = "Avg: %.2f°C".format(average)
            } else {
                Toast.makeText(this, "Fix inputs", Toast.LENGTH_SHORT).show()
            }
        }

        btnDetails.setOnClickListener {
            startActivity(Intent(this, DetailedActivity::class.java).apply {
                putExtra("temps", temps)
            })
        }

        btnClear.setOnClickListener {
            inputs.forEach { it.text.clear() }
            tvAvg.text = ""
        }

        btnExit.setOnClickListener { finish() }
    }
}

class DetailedActivity(parcel: Parcel) {

}
