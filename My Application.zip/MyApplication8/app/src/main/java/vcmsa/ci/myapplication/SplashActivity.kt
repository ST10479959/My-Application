package com.example.myapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import androidx.core.SplashScreen.Companion.installSplashScreen
import android.widget.TextView


class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()  // Uses AndroidX SplashScreen API :contentReference[oaicite:1]{index=1}
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val studentTv = findViewById<TextView>(R.id.tvStudent)
        studentTv.text = "Lesego Matjie\nST10479959"

        Handler(mainLooper).postDelayed({
            startActivity(Intent(this, WeeklyActivity::class.java))
            finish()
        }, 1500L)
    }

    private fun installSplashScreen(): Any {

    }
}
